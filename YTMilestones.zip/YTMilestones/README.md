# Milestones — YouTube milestone alerts for Android

Add any channel by its @handle and get notifications when it hits goals you set.

## Alerts you can set

**Per channel**
- Subscribers reach a goal (e.g. 1,000)
- Every N subscribers (e.g. every 100)
- Total channel views reach a goal
- Any recent video reaches N views (e.g. every new upload hitting 100 views)
- New video uploaded

**Per video** (from the channel's 10 newest, or any older video added by link)
- Views, likes or comments reach a goal

Tapping a video alert opens that video on YouTube. Each channel also shows live stats and progress bars for every goal.

## One-time setup: free YouTube API key
1. Go to https://console.cloud.google.com and create a project.
2. APIs & Services → Library → "YouTube Data API v3" → Enable.
3. APIs & Services → Credentials → Create credentials → API key.
4. In the app: Settings → paste the key → Save.

If you restrict the key, restrict it to "YouTube Data API v3" only (not to Android apps). The free quota is 10,000 units/day; each check costs about 3 units per channel, so checking every 15 minutes is fine for dozens of channels.

## Building the APK

### Option A — GitHub (no PC software needed)
1. Create a new GitHub repository and upload this whole folder (keep the `.github` folder).
2. GitHub Actions builds automatically: open the **Actions** tab → latest "Build APK" run → download **YT-Milestones-apk**.
3. Unzip it on your phone, open the `.apk`, and allow "install unknown apps" when asked.

### Option B — Android Studio
Open the folder in Android Studio (Ladybug or newer), let it sync, then Run on your phone or use Build → Build APK(s).

## Notes
- YouTube rounds public subscriber counts above 1,000 (12,345 shows as 12,300), so subscriber alerts fire when the rounded figure passes your goal. Channels that hide their count can't use subscriber alerts.
- Android batches background work to save battery. Checks run roughly on your chosen interval (minimum 15 minutes). If alerts arrive late, set the app's battery usage to "Unrestricted".
- Tech: Kotlin, Jetpack Compose (Material 3), WorkManager, YouTube Data API v3. Min Android 8.0.
