package com.fin.ytmilestones.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tiny persistent store shared by the UI and the background worker. */
object Store {
    private lateinit var prefs: SharedPreferences

    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels.asStateFlow()

    private val _apiKey = MutableStateFlow("")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _interval = MutableStateFlow(30)
    val interval: StateFlow<Int> = _interval.asStateFlow()

    @Synchronized
    fun init(ctx: Context) {
        if (::prefs.isInitialized) return
        prefs = ctx.applicationContext.getSharedPreferences("store", Context.MODE_PRIVATE)
        _apiKey.value = prefs.getString("apiKey", "") ?: ""
        _interval.value = prefs.getInt("interval", 30)
        _channels.value = runCatching {
            channelsFromJson(prefs.getString("channels", "[]") ?: "[]")
        }.getOrDefault(emptyList())
    }

    fun setApiKey(key: String) {
        _apiKey.value = key.trim()
        prefs.edit().putString("apiKey", key.trim()).commit()
    }

    fun setInterval(minutes: Int) {
        _interval.value = minutes
        prefs.edit().putInt("interval", minutes).commit()
    }

    @Synchronized
    fun update(transform: (List<Channel>) -> List<Channel>) {
        val next = transform(_channels.value)
        _channels.value = next
        prefs.edit().putString("channels", channelsToJson(next)).commit()
    }

    fun updateChannel(id: String, transform: (Channel) -> Channel) =
        update { list -> list.map { if (it.id == id) transform(it) else it } }
}
