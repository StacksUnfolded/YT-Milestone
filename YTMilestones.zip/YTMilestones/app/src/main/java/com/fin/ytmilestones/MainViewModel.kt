package com.fin.ytmilestones

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fin.ytmilestones.data.Alert
import com.fin.ytmilestones.data.ApiException
import com.fin.ytmilestones.data.Channel
import com.fin.ytmilestones.data.Checker
import com.fin.ytmilestones.data.Rule
import com.fin.ytmilestones.data.RuleType
import com.fin.ytmilestones.data.Store
import com.fin.ytmilestones.data.YouTubeApi
import com.fin.ytmilestones.data.nextMilestone
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.UUID

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val channels = Store.channels
    val apiKey = Store.apiKey
    val interval = Store.interval
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    var busy by mutableStateOf(false)
        private set

    private fun newId() = UUID.randomUUID().toString()

    private fun requireKey(): String =
        Store.apiKey.value.ifBlank { throw ApiException("Add your YouTube API key in Settings first") }

    /** Runs a network task with a spinner; the block returns an optional message to show. */
    private fun launchBusy(onSuccess: () -> Unit = {}, block: suspend () -> String?) {
        if (busy) return
        viewModelScope.launch {
            busy = true
            try {
                block()?.let { messages.tryEmit(it) }
                onSuccess()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                messages.tryEmit(e.message ?: "YouTube error")
            } catch (e: IOException) {
                messages.tryEmit("Network error — check your connection")
            } catch (e: Exception) {
                messages.tryEmit("Something went wrong: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    fun addChannel(input: String, onDone: () -> Unit) = launchBusy(onDone) {
        val key = requireKey()
        val info = YouTubeApi.lookupChannel(input, key)
        if (channels.value.any { it.id == info.id }) return@launchBusy "Already tracking ${info.title}"
        val recent = YouTubeApi.recentUploadIds(info.uploads, key)
        val videos = YouTubeApi.videosByIds(recent, key)
        val rules = buildList {
            add(Rule(newId(), RuleType.NEW_UPLOAD, 0))
            if (!info.subsHidden) add(Rule(newId(), RuleType.SUBS_REACH, nextMilestone(info.subs)))
        }
        Store.update {
            it + Channel(
                id = info.id, handle = info.handle.ifBlank { input.trim() }, title = info.title,
                thumb = info.thumb, uploadsPlaylist = info.uploads, subs = info.subs,
                subsHidden = info.subsHidden, views = info.views, videoCount = info.videoCount,
                lastChecked = System.currentTimeMillis(), videos = videos,
                extraVideoIds = emptySet(), rules = rules, knownUploadIds = recent.toSet(),
            )
        }
        "Added ${info.title}"
    }

    fun removeChannel(id: String) = Store.update { list -> list.filterNot { it.id == id } }

    fun addRule(channelId: String, type: RuleType, target: Long, videoId: String?) {
        Store.updateChannel(channelId) { ch ->
            var rule = Rule(newId(), type, target, videoId)
            if (type == RuleType.SUBS_EVERY && !ch.subsHidden && target > 0) {
                rule = rule.copy(lastBucket = ch.subs / target)
            }
            if (type == RuleType.ANY_VIDEO_VIEWS) {
                // Don't spam about videos that are already past the goal.
                rule = rule.copy(firedVideoIds = ch.videos.filter { it.views >= target }.map { it.id }.toSet())
            }
            ch.copy(rules = ch.rules + rule)
        }
    }

    fun removeRule(channelId: String, ruleId: String) =
        Store.updateChannel(channelId) { ch -> ch.copy(rules = ch.rules.filterNot { it.id == ruleId }) }

    fun trackVideo(channelId: String, input: String, onDone: () -> Unit) = launchBusy(onDone) {
        val key = requireKey()
        val videoId = YouTubeApi.parseVideoId(input) ?: throw ApiException("That doesn't look like a YouTube video link")
        val video = YouTubeApi.videosByIds(listOf(videoId), key).firstOrNull()
            ?: throw ApiException("Video not found (it may be private)")
        if (video.channelId != channelId) throw ApiException("That video belongs to a different channel")
        Store.updateChannel(channelId) { ch ->
            ch.copy(
                extraVideoIds = ch.extraVideoIds + video.id,
                videos = if (ch.videos.any { it.id == video.id }) ch.videos else ch.videos + video,
            )
        }
        "Now tracking “${video.title}”"
    }

    fun untrackVideo(channelId: String, videoId: String) = Store.updateChannel(channelId) { ch ->
        ch.copy(
            extraVideoIds = ch.extraVideoIds - videoId,
            videos = ch.videos.filterNot { it.id == videoId },
            rules = ch.rules.filterNot { it.videoId == videoId },
        )
    }

    fun refresh() = launchBusy {
        val n = Checker.checkAll(app)
        if (n == 0) "Up to date — no new milestones" else "$n new alert${if (n == 1) "" else "s"}"
    }

    fun saveApiKey(key: String) {
        Store.setApiKey(key)
        messages.tryEmit("API key saved")
    }

    fun setInterval(minutes: Int) {
        Store.setInterval(minutes)
        Scheduler.schedule(app, minutes, replace = true)
    }

    fun sendTest() = Notifier.show(app, Alert("🎉 Test notification", "Milestone alerts are working.", null))
}
