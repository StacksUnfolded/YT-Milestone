package com.fin.ytmilestones.data

import android.content.Context
import com.fin.ytmilestones.Notifier
import java.text.NumberFormat
import java.util.Locale

data class Alert(val title: String, val text: String, val videoId: String?)

fun full(n: Long): String = NumberFormat.getIntegerInstance().format(n)

fun compact(n: Long): String {
    fun f(d: Double) = if (d >= 100) String.format(Locale.UK, "%.0f", d)
    else String.format(Locale.UK, "%.1f", d).removeSuffix(".0")
    return when {
        n >= 1_000_000_000 -> f(n / 1e9) + "B"
        n >= 1_000_000 -> f(n / 1e6) + "M"
        n >= 1_000 -> f(n / 1e3) + "K"
        else -> n.toString()
    }
}

/** Next "round" goal above n: 10, 25, 50, 100, 250, 500, 1K, 2.5K … */
fun nextMilestone(n: Long): Long {
    var base = 1L
    while (true) {
        for (m in longArrayOf(10, 25, 50)) if (m * base > n) return m * base
        base *= 10
    }
}

object Checker {

    /** Refreshes every channel, fires notifications, returns how many alerts fired. */
    suspend fun checkAll(ctx: Context): Int {
        val key = Store.apiKey.value
        if (key.isBlank()) throw ApiException("Add your YouTube API key in Settings first")
        val snapshot = Store.channels.value
        if (snapshot.isEmpty()) return 0

        val infos = YouTubeApi.channelsByIds(snapshot.map { it.id }, key).associateBy { it.id }
        val alerts = mutableListOf<Alert>()
        val updated = mutableMapOf<String, Channel>()

        for (ch in snapshot) {
            val info = infos[ch.id] ?: continue
            val recent = YouTubeApi.recentUploadIds(info.uploads, key)
            val watched = ch.rules.mapNotNull { it.videoId } + ch.extraVideoIds
            val allIds = (recent + watched).distinct()
            val fetched = YouTubeApi.videosByIds(allIds, key).associateBy { it.id }
            val videos = allIds.mapNotNull { fetched[it] }

            val (rules, chAlerts) = evaluate(ch, info, videos, recent)
            alerts += chAlerts
            updated[ch.id] = ch.copy(
                handle = info.handle.ifBlank { ch.handle },
                title = info.title,
                thumb = info.thumb,
                uploadsPlaylist = info.uploads,
                subs = info.subs,
                subsHidden = info.subsHidden,
                views = info.views,
                videoCount = info.videoCount,
                lastChecked = System.currentTimeMillis(),
                videos = videos,
                rules = rules,
                knownUploadIds = (recent + ch.knownUploadIds).distinct().take(100).toSet(),
            )
        }

        // Merge into the latest state so edits made during the check aren't lost.
        Store.update { current ->
            current.map { c ->
                val u = updated[c.id] ?: return@map c
                val evaluated = u.rules.associateBy { it.id }
                u.copy(
                    rules = c.rules.map { r -> evaluated[r.id] ?: r },
                    extraVideoIds = c.extraVideoIds,
                )
            }
        }
        alerts.forEach { Notifier.show(ctx, it) }
        return alerts.size
    }

    private fun evaluate(
        ch: Channel,
        info: ChannelInfo,
        videos: List<Video>,
        recent: List<String>,
    ): Pair<List<Rule>, List<Alert>> {
        val alerts = mutableListOf<Alert>()
        val byId = videos.associateBy { it.id }
        val recentVideos = recent.mapNotNull { byId[it] }
        val newUploads = if (ch.knownUploadIds.isEmpty()) emptyList()
        else recentVideos.filter { it.id !in ch.knownUploadIds }
        val name = info.title

        val rules = ch.rules.map { r ->
            when (r.type) {
                RuleType.SUBS_REACH ->
                    if (!r.done && !info.subsHidden && info.subs >= r.target) {
                        alerts += Alert(
                            "🎉 $name hit ${full(r.target)} subscribers",
                            "Now at ${full(info.subs)} subscribers.", null,
                        )
                        r.copy(done = true)
                    } else r

                RuleType.CHANNEL_VIEWS_REACH ->
                    if (!r.done && info.views >= r.target) {
                        alerts += Alert(
                            "👀 $name hit ${full(r.target)} total views",
                            "Now at ${full(info.views)} views.", null,
                        )
                        r.copy(done = true)
                    } else r

                RuleType.SUBS_EVERY -> {
                    if (info.subsHidden || r.target <= 0) r else {
                        val bucket = info.subs / r.target
                        when {
                            r.lastBucket < 0 -> r.copy(lastBucket = bucket)
                            bucket > r.lastBucket -> {
                                alerts += Alert(
                                    "📈 $name passed ${full(bucket * r.target)} subscribers",
                                    "Next stop: ${full((bucket + 1) * r.target)}.", null,
                                )
                                r.copy(lastBucket = bucket)
                            }
                            else -> r
                        }
                    }
                }

                RuleType.ANY_VIDEO_VIEWS -> {
                    val hits = recentVideos.filter { it.views >= r.target && it.id !in r.firedVideoIds }
                    hits.forEach { v ->
                        alerts += Alert(
                            "🔥 “${v.title}” hit ${full(r.target)} views",
                            "$name · now at ${full(v.views)} views", v.id,
                        )
                    }
                    if (hits.isEmpty()) r else r.copy(firedVideoIds = r.firedVideoIds + hits.map { it.id })
                }

                RuleType.NEW_UPLOAD -> {
                    newUploads.forEach { alerts += Alert("🆕 $name just uploaded", it.title, it.id) }
                    r
                }

                RuleType.VIDEO_VIEWS, RuleType.VIDEO_LIKES, RuleType.VIDEO_COMMENTS -> {
                    val v = r.videoId?.let { byId[it] }
                    if (r.done || v == null) r else {
                        val (cur, noun) = when (r.type) {
                            RuleType.VIDEO_VIEWS -> v.views to "views"
                            RuleType.VIDEO_LIKES -> v.likes to "likes"
                            else -> v.comments to "comments"
                        }
                        if (cur >= r.target) {
                            alerts += Alert(
                                "🎯 “${v.title}” hit ${full(r.target)} $noun",
                                "$name · now at ${full(cur)} $noun", v.id,
                            )
                            r.copy(done = true)
                        } else r
                    }
                }
            }
        }
        return rules to alerts
    }
}
