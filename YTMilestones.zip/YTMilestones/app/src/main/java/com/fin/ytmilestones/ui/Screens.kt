@file:OptIn(ExperimentalMaterial3Api::class)

package com.fin.ytmilestones.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.fin.ytmilestones.MainViewModel
import com.fin.ytmilestones.data.Channel
import com.fin.ytmilestones.data.Rule
import com.fin.ytmilestones.data.RuleType
import com.fin.ytmilestones.data.Scope
import com.fin.ytmilestones.data.Video
import com.fin.ytmilestones.data.compact
import com.fin.ytmilestones.data.full

// ---------------------------------------------------------------- navigation

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val channels by vm.channels.collectAsStateWithLifecycle()
    val apiKey by vm.apiKey.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf("home") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    BackHandler(enabled = screen != "home") { screen = "home" }

    when {
        screen == "settings" -> SettingsScreen(vm, snackbar) { screen = "home" }
        screen.startsWith("channel:") -> {
            val ch = channels.find { it.id == screen.removePrefix("channel:") }
            if (ch == null) LaunchedEffect(Unit) { screen = "home" }
            else ChannelScreen(ch, vm, snackbar) { screen = "home" }
        }
        else -> HomeScreen(
            channels, apiKey, vm, snackbar,
            onOpen = { screen = "channel:$it" },
            onSettings = { screen = "settings" },
        )
    }
}

// ---------------------------------------------------------------- shared bits

private fun openUrl(ctx: Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun ago(ts: Long): String =
    if (ts == 0L) "never checked"
    else "checked " + DateUtils.getRelativeTimeSpanString(
        ts, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
    )

@Composable
private fun Avatar(url: String, size: Dp) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
    )
}

@Composable
private fun RefreshAction(vm: MainViewModel) {
    if (vm.busy) {
        Box(Modifier.padding(12.dp)) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        }
    } else {
        IconButton(onClick = vm::refresh) { Icon(Icons.Default.Refresh, "Check now") }
    }
}

@Composable
private fun SectionHeader(title: String, action: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        TextButton(onClick = onAction) {
            Icon(Icons.Default.Add, null, Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text(action)
        }
    }
}

@Composable
private fun LinkDialog(
    title: String,
    hint: String,
    placeholder: String,
    confirm: String,
    busy: Boolean,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(hint, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text(placeholder) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank() && !busy, onClick = { onConfirm(text) }) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Text(confirm)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- home

@Composable
private fun HomeScreen(
    channels: List<Channel>,
    apiKey: String,
    vm: MainViewModel,
    snackbar: SnackbarHostState,
    onOpen: (String) -> Unit,
    onSettings: () -> Unit,
) {
    var showAdd by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Milestones", fontWeight = FontWeight.SemiBold) },
                actions = {
                    RefreshAction(vm)
                    IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Add channel") },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (apiKey.isBlank()) item { SetupCard(onSettings) }
            if (channels.isEmpty()) item {
                Text(
                    "No channels yet.\nTap “Add channel” and enter an @handle to start tracking milestones.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 48.dp),
                )
            }
            items(channels, key = { it.id }) { ch -> ChannelCard(ch) { onOpen(ch.id) } }
        }
    }
    if (showAdd) {
        LinkDialog(
            title = "Add a channel",
            hint = "Enter the channel's @handle or paste its link.",
            placeholder = "@yourchannel",
            confirm = "Add",
            busy = vm.busy,
            onConfirm = { vm.addChannel(it) { showAdd = false } },
            onDismiss = { showAdd = false },
        )
    }
}

@Composable
private fun SetupCard(onSettings: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("One-time setup", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "The app needs a free YouTube Data API key to read channel stats. It takes about two minutes to get one.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = onSettings) { Text("Set up API key") }
        }
    }
}

@Composable
private fun ChannelCard(ch: Channel, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(ch.thumb, 52.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    ch.title, style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    ch.handle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "${if (ch.subsHidden) "Hidden" else compact(ch.subs)} subs · " +
                        "${compact(ch.views)} views · ${ch.videoCount} videos",
                    style = MaterialTheme.typography.bodyMedium,
                )
                val active = ch.rules.count { !it.done }
                Text(
                    "$active active alert${if (active == 1) "" else "s"} · ${ago(ch.lastChecked)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- channel

private data class RuleTarget(val video: Video?)

@Composable
private fun ChannelScreen(ch: Channel, vm: MainViewModel, snackbar: SnackbarHostState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var ruleFor by remember { mutableStateOf<RuleTarget?>(null) }
    var showTrack by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ch.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    RefreshAction(vm)
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Remove channel") }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { StatsHeader(ch) }
            item { SectionHeader("Alerts", "Add alert") { ruleFor = RuleTarget(null) } }
            if (ch.rules.isEmpty()) item {
                Text("No alerts yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(ch.rules, key = { it.id }) { r -> RuleRow(r, ch) { vm.removeRule(ch.id, r.id) } }
            item { SectionHeader("Videos", "Track by link") { showTrack = true } }
            if (ch.videos.isEmpty()) item {
                Text("No videos found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(ch.videos, key = { "v_" + it.id }) { v ->
                VideoRow(
                    v = v,
                    isExtra = v.id in ch.extraVideoIds,
                    alertCount = ch.rules.count { it.videoId == v.id && !it.done },
                    onAlert = { ruleFor = RuleTarget(v) },
                    onUntrack = { vm.untrackVideo(ch.id, v.id) },
                    onOpen = { openUrl(ctx, "https://youtu.be/${v.id}") },
                )
            }
        }
    }

    ruleFor?.let { target ->
        AddRuleDialog(
            ch = ch,
            video = target.video,
            onAdd = { type, value -> vm.addRule(ch.id, type, value, target.video?.id) },
            onDismiss = { ruleFor = null },
        )
    }
    if (showTrack) {
        LinkDialog(
            title = "Track a video",
            hint = "Paste a link to any video from this channel — handy for older videos.",
            placeholder = "https://youtu.be/…",
            confirm = "Track",
            busy = vm.busy,
            onConfirm = { vm.trackVideo(ch.id, it) { showTrack = false } },
            onDismiss = { showTrack = false },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Remove ${ch.title}?") },
            text = { Text("Its alerts will be deleted too.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.removeChannel(ch.id); onBack() }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun StatsHeader(ch: Channel) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Avatar(ch.thumb, 72.dp)
            Spacer(Modifier.height(8.dp))
            Text(ch.title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
            Text(ch.handle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("Subscribers", if (ch.subsHidden) "Hidden" else full(ch.subs))
                Stat("Views", full(ch.views))
                Stat("Videos", full(ch.videoCount))
            }
            if (!ch.subsHidden && ch.subs >= 1000) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "YouTube rounds public subscriber counts (e.g. 12,345 shows as 12,300), so subscriber alerts fire when the rounded number passes your goal.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(ago(ch.lastChecked), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private data class RuleInfo(val title: String, val current: Long?, val note: String?)

private fun describe(r: Rule, ch: Channel): RuleInfo {
    val t = full(r.target)
    fun videoStat(pick: (Video) -> Long, noun: String): RuleInfo {
        val v = ch.videos.find { it.id == r.videoId }
        val name = v?.title ?: "Tracked video"
        return RuleInfo("“$name” — $noun reach $t", v?.let(pick), null)
    }
    return when (r.type) {
        RuleType.SUBS_REACH -> RuleInfo("Subscribers reach $t", if (ch.subsHidden) null else ch.subs, null)
        RuleType.SUBS_EVERY -> RuleInfo(
            "Every $t subscribers", null,
            if (ch.subsHidden || r.target <= 0) null else "Next: ${full((ch.subs / r.target + 1) * r.target)}",
        )
        RuleType.CHANNEL_VIEWS_REACH -> RuleInfo("Channel views reach $t", ch.views, null)
        RuleType.ANY_VIDEO_VIEWS -> RuleInfo(
            "Any recent video reaches $t views", null,
            "${r.firedVideoIds.size} video${if (r.firedVideoIds.size == 1) "" else "s"} already past it",
        )
        RuleType.NEW_UPLOAD -> RuleInfo("New uploads", null, "Notifies when a new video goes live")
        RuleType.VIDEO_VIEWS -> videoStat({ it.views }, "views")
        RuleType.VIDEO_LIKES -> videoStat({ it.likes }, "likes")
        RuleType.VIDEO_COMMENTS -> videoStat({ it.comments }, "comments")
    }
}

@Composable
private fun RuleRow(r: Rule, ch: Channel, onDelete: () -> Unit) {
    val info = describe(r, ch)
    val cur = info.current
    val note = info.note
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(info.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                when {
                    r.done -> Text("Reached ✓", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    cur != null && r.target > 0 -> {
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (cur.toFloat() / r.target).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${full(cur)} / ${full(r.target)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    note != null -> Text(
                        note, style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete alert") }
        }
    }
}

@Composable
private fun VideoRow(
    v: Video,
    isExtra: Boolean,
    alertCount: Int,
    onAlert: () -> Unit,
    onUntrack: () -> Unit,
    onOpen: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model = v.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .width(120.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                "${compact(v.views)} views · ${compact(v.likes)} likes · ${compact(v.comments)} comments",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val tags = listOfNotNull(
                if (isExtra) "Tracked" else null,
                if (alertCount > 0) "$alertCount alert${if (alertCount == 1) "" else "s"}" else null,
            )
            if (tags.isNotEmpty()) Text(
                tags.joinToString(" · "), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        IconButton(onClick = onAlert) { Icon(Icons.Default.Notifications, "Add alert for this video") }
        if (isExtra) IconButton(onClick = onUntrack) { Icon(Icons.Default.Close, "Stop tracking") }
    }
}

@Composable
private fun AddRuleDialog(
    ch: Channel,
    video: Video?,
    onAdd: (RuleType, Long) -> Unit,
    onDismiss: () -> Unit,
) {
    val scope = if (video == null) Scope.CHANNEL else Scope.VIDEO
    val types = RuleType.entries.filter { it.scope == scope }
    var type by remember { mutableStateOf(types.first()) }
    var text by remember { mutableStateOf("") }
    val target = text.toLongOrNull()

    val hint: String? = when (type) {
        RuleType.SUBS_REACH, RuleType.SUBS_EVERY ->
            if (ch.subsHidden) "This channel hides its subscriber count" else "Currently ${full(ch.subs)}"
        RuleType.CHANNEL_VIEWS_REACH -> "Currently ${full(ch.views)}"
        RuleType.ANY_VIDEO_VIEWS -> "Checks the channel's 10 newest videos"
        RuleType.VIDEO_VIEWS -> video?.let { "Currently ${full(it.views)}" }
        RuleType.VIDEO_LIKES -> video?.let { "Currently ${full(it.likes)}" }
        RuleType.VIDEO_COMMENTS -> video?.let { "Currently ${full(it.comments)}" }
        RuleType.NEW_UPLOAD -> null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (video == null) "New channel alert" else "New video alert") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (video != null) {
                    Text(
                        video.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                }
                types.forEach { t ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .selectable(selected = t == type, onClick = { type = t }, role = Role.RadioButton)
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = t == type, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Text(t.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (type.needsTarget) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { v -> text = v.filter { it.isDigit() }.take(12) },
                        label = { Text(if (type == RuleType.SUBS_EVERY) "Every how many?" else "Goal") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        supportingText = { if (hint != null) Text(hint) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !type.needsTarget || (target != null && target > 0),
                onClick = { onAdd(type, target ?: 0L); onDismiss() },
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- settings

@Composable
private fun SettingsScreen(vm: MainViewModel, snackbar: SnackbarHostState, onBack: () -> Unit) {
    val savedKey by vm.apiKey.collectAsStateWithLifecycle()
    val interval by vm.interval.collectAsStateWithLifecycle()
    var key by remember { mutableStateOf(savedKey) }
    val ctx = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("YouTube API key", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = key,
                onValueChange = { key = it.trim() },
                label = { Text("API key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = { vm.saveApiKey(key) }, enabled = key.isNotBlank() && key != savedKey) {
                Text("Save key")
            }
            OutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("How to get a free key", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "1. Open Google Cloud Console and create a project (any name).\n" +
                            "2. APIs & Services → Library → search “YouTube Data API v3” → Enable.\n" +
                            "3. APIs & Services → Credentials → Create credentials → API key.\n" +
                            "4. Paste it above. If you restrict the key, restrict it to “YouTube Data API v3” — not to Android apps.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    TextButton(onClick = { openUrl(ctx, "https://console.cloud.google.com/apis/library/youtube.googleapis.com") }) {
                        Text("Open Google Cloud Console")
                    }
                }
            }

            HorizontalDivider()
            Text("Check every", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15 to "15 min", 30 to "30 min", 60 to "1 hr", 180 to "3 hr").forEach { (m, label) ->
                    FilterChip(selected = interval == m, onClick = { vm.setInterval(m) }, label = { Text(label) })
                }
            }
            Text(
                "Android runs background checks roughly on this schedule and may delay them to save battery. Each check uses a few of your 10,000 free daily API units.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider()
            Text("Notifications", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = vm::sendTest) { Text("Send test notification") }
            OutlinedButton(onClick = {
                runCatching {
                    ctx.startActivity(
                        Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }) { Text("App, battery & notification settings") }
            Text(
                "If alerts arrive late or not at all, set this app's battery usage to “Unrestricted”.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
