package com.fin.ytmilestones.data

import org.json.JSONArray
import org.json.JSONObject

enum class Scope { CHANNEL, VIDEO }

enum class RuleType(val label: String, val scope: Scope, val needsTarget: Boolean = true) {
    SUBS_REACH("Subscribers reach a goal", Scope.CHANNEL),
    SUBS_EVERY("Every N subscribers", Scope.CHANNEL),
    CHANNEL_VIEWS_REACH("Total channel views reach a goal", Scope.CHANNEL),
    ANY_VIDEO_VIEWS("Any recent video reaches N views", Scope.CHANNEL),
    NEW_UPLOAD("New video uploaded", Scope.CHANNEL, needsTarget = false),
    VIDEO_VIEWS("Views reach a goal", Scope.VIDEO),
    VIDEO_LIKES("Likes reach a goal", Scope.VIDEO),
    VIDEO_COMMENTS("Comments reach a goal", Scope.VIDEO),
}

data class Rule(
    val id: String,
    val type: RuleType,
    val target: Long,
    val videoId: String? = null,
    /** One-shot goals flip to done once reached. */
    val done: Boolean = false,
    /** SUBS_EVERY: highest multiple of target already announced. */
    val lastBucket: Long = -1,
    /** ANY_VIDEO_VIEWS: videos already announced. */
    val firedVideoIds: Set<String> = emptySet(),
)

data class Video(
    val id: String,
    val title: String,
    val thumb: String,
    val publishedAt: String,
    val views: Long,
    val likes: Long,
    val comments: Long,
    val channelId: String = "",
)

data class Channel(
    val id: String,
    val handle: String,
    val title: String,
    val thumb: String,
    val uploadsPlaylist: String,
    val subs: Long,
    val subsHidden: Boolean,
    val views: Long,
    val videoCount: Long,
    val lastChecked: Long,
    val videos: List<Video>,
    /** Videos the user added by link (older than the recent-uploads window). */
    val extraVideoIds: Set<String>,
    val rules: List<Rule>,
    val knownUploadIds: Set<String>,
)

// ---------- JSON persistence ----------

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
private fun Collection<String>.toJsonArray() = JSONArray(this.toList())

private fun Rule.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("type", type.name)
    .put("target", target)
    .put("videoId", videoId ?: "")
    .put("done", done)
    .put("lastBucket", lastBucket)
    .put("fired", firedVideoIds.toJsonArray())

private fun ruleFromJson(o: JSONObject) = Rule(
    id = o.getString("id"),
    type = RuleType.valueOf(o.getString("type")),
    target = o.getLong("target"),
    videoId = o.optString("videoId", "").ifEmpty { null },
    done = o.optBoolean("done", false),
    lastBucket = o.optLong("lastBucket", -1),
    firedVideoIds = (o.optJSONArray("fired") ?: JSONArray()).strings().toSet(),
)

private fun Video.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("thumb", thumb).put("publishedAt", publishedAt)
    .put("views", views).put("likes", likes).put("comments", comments)

private fun videoFromJson(o: JSONObject) = Video(
    id = o.getString("id"),
    title = o.optString("title"),
    thumb = o.optString("thumb"),
    publishedAt = o.optString("publishedAt"),
    views = o.optLong("views"),
    likes = o.optLong("likes"),
    comments = o.optLong("comments"),
)

private fun Channel.toJson(): JSONObject = JSONObject()
    .put("id", id).put("handle", handle).put("title", title).put("thumb", thumb)
    .put("uploads", uploadsPlaylist).put("subs", subs).put("subsHidden", subsHidden)
    .put("views", views).put("videoCount", videoCount).put("lastChecked", lastChecked)
    .put("videos", JSONArray(videos.map { it.toJson() }))
    .put("extra", extraVideoIds.toJsonArray())
    .put("rules", JSONArray(rules.map { it.toJson() }))
    .put("known", knownUploadIds.toJsonArray())

private fun channelFromJson(o: JSONObject) = Channel(
    id = o.getString("id"),
    handle = o.optString("handle"),
    title = o.optString("title"),
    thumb = o.optString("thumb"),
    uploadsPlaylist = o.optString("uploads"),
    subs = o.optLong("subs"),
    subsHidden = o.optBoolean("subsHidden"),
    views = o.optLong("views"),
    videoCount = o.optLong("videoCount"),
    lastChecked = o.optLong("lastChecked"),
    videos = (o.optJSONArray("videos") ?: JSONArray()).objects()
        .mapNotNull { runCatching { videoFromJson(it) }.getOrNull() },
    extraVideoIds = (o.optJSONArray("extra") ?: JSONArray()).strings().toSet(),
    rules = (o.optJSONArray("rules") ?: JSONArray()).objects()
        .mapNotNull { runCatching { ruleFromJson(it) }.getOrNull() },
    knownUploadIds = (o.optJSONArray("known") ?: JSONArray()).strings().toSet(),
)

fun channelsToJson(list: List<Channel>): String = JSONArray(list.map { it.toJson() }).toString()

fun channelsFromJson(s: String): List<Channel> =
    JSONArray(s).objects().mapNotNull { runCatching { channelFromJson(it) }.getOrNull() }
