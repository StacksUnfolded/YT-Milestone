package com.fin.ytmilestones.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ApiException(message: String) : Exception(message)

data class ChannelInfo(
    val id: String,
    val handle: String,
    val title: String,
    val thumb: String,
    val uploads: String,
    val subs: Long,
    val subsHidden: Boolean,
    val views: Long,
    val videoCount: Long,
)

/**
 * Minimal YouTube Data API v3 client. Every call used here costs 1 quota unit
 * (the free daily quota is 10,000 units), so frequent checks are fine.
 */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3/"

    private suspend fun get(path: String, params: Map<String, String>, key: String): JSONObject =
        withContext(Dispatchers.IO) {
            val query = (params + ("key" to key)).entries.joinToString("&") {
                "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}"
            }
            val conn = URL("$BASE$path?$query").openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 15_000
            try {
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val msg = runCatching {
                        JSONObject(body).getJSONObject("error").getString("message")
                    }.getOrNull()?.replace(Regex("<[^>]+>"), "") ?: "HTTP $code"
                    throw ApiException("YouTube API: $msg")
                }
                JSONObject(body)
            } finally {
                conn.disconnect()
            }
        }

    private fun JSONObject.thumb(): String {
        val t = optJSONObject("thumbnails") ?: return ""
        val best = t.optJSONObject("medium") ?: t.optJSONObject("high")
            ?: t.optJSONObject("default") ?: return ""
        return best.optString("url")
    }

    private fun parseChannel(o: JSONObject): ChannelInfo {
        val sn = o.getJSONObject("snippet")
        val st = o.optJSONObject("statistics") ?: JSONObject()
        val cd = o.getJSONObject("contentDetails")
        return ChannelInfo(
            id = o.getString("id"),
            handle = sn.optString("customUrl"),
            title = sn.optString("title"),
            thumb = sn.thumb(),
            uploads = cd.getJSONObject("relatedPlaylists").optString("uploads"),
            subs = st.optLong("subscriberCount"),
            subsHidden = st.optBoolean("hiddenSubscriberCount"),
            views = st.optLong("viewCount"),
            videoCount = st.optLong("videoCount"),
        )
    }

    /** Accepts @handle, handle, a channel URL, or a UC… channel ID. */
    private fun lookupParam(input: String): Pair<String, String> {
        val s = input.trim()
        Regex("youtube\\.com/(?:(@[^/?#\\s]+)|channel/(UC[\\w-]{22}))").find(s)?.let { m ->
            return if (m.groupValues[2].isNotEmpty()) "id" to m.groupValues[2]
            else "forHandle" to m.groupValues[1]
        }
        if (Regex("UC[\\w-]{22}").matches(s)) return "id" to s
        return "forHandle" to "@${s.removePrefix("@")}"
    }

    suspend fun lookupChannel(input: String, key: String): ChannelInfo {
        val (param, value) = lookupParam(input)
        val res = get(
            "channels",
            mapOf("part" to "snippet,statistics,contentDetails", param to value),
            key,
        )
        val items = res.optJSONArray("items")
        if (items == null || items.length() == 0) throw ApiException("No channel found for \"$input\"")
        return parseChannel(items.getJSONObject(0))
    }

    suspend fun channelsByIds(ids: List<String>, key: String): List<ChannelInfo> =
        ids.distinct().chunked(50).flatMap { chunk ->
            val res = get(
                "channels",
                mapOf("part" to "snippet,statistics,contentDetails", "id" to chunk.joinToString(",")),
                key,
            )
            val items = res.optJSONArray("items") ?: return@flatMap emptyList()
            (0 until items.length()).map { parseChannel(items.getJSONObject(it)) }
        }

    /** IDs of the channel's newest uploads, newest first. */
    suspend fun recentUploadIds(playlistId: String, key: String, max: Int = 10): List<String> {
        if (playlistId.isBlank()) return emptyList()
        val res = try {
            get(
                "playlistItems",
                mapOf("part" to "contentDetails", "playlistId" to playlistId, "maxResults" to "$max"),
                key,
            )
        } catch (e: ApiException) {
            // Channels with no uploads return 404 for their uploads playlist.
            if (e.message?.contains("cannot be found", ignoreCase = true) == true) return emptyList()
            throw e
        }
        val items = res.optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).map {
            items.getJSONObject(it).getJSONObject("contentDetails").getString("videoId")
        }
    }

    suspend fun videosByIds(ids: List<String>, key: String): List<Video> =
        ids.distinct().chunked(50).flatMap { chunk ->
            if (chunk.isEmpty()) return@flatMap emptyList()
            val res = get(
                "videos",
                mapOf("part" to "snippet,statistics", "id" to chunk.joinToString(",")),
                key,
            )
            val items = res.optJSONArray("items") ?: return@flatMap emptyList()
            (0 until items.length()).map {
                val o = items.getJSONObject(it)
                val sn = o.getJSONObject("snippet")
                val st = o.optJSONObject("statistics") ?: JSONObject()
                Video(
                    id = o.getString("id"),
                    title = sn.optString("title"),
                    thumb = sn.thumb(),
                    publishedAt = sn.optString("publishedAt"),
                    views = st.optLong("viewCount"),
                    likes = st.optLong("likeCount"),
                    comments = st.optLong("commentCount"),
                    channelId = sn.optString("channelId"),
                )
            }
        }

    /** Pulls a video ID out of any YouTube link (watch, youtu.be, shorts, live) or a bare ID. */
    fun parseVideoId(input: String): String? {
        val s = input.trim()
        if (Regex("[\\w-]{11}").matches(s)) return s
        return Regex("(?:v=|youtu\\.be/|shorts/|live/|embed/)([\\w-]{11})")
            .find(s)?.groupValues?.get(1)
    }
}
